<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class cutefilebrowserController extends appRain_Base_Core
{
    public $name = 'Cutefilebrowser';
    
    public function __preDispatch(){
		
		$this->page_title = 'File Browser';
		
		 # If required 	membership to browser file
		 # This feature need to install Member component
         # App::Component('Members')
         #       ->Helper('Auth')
         #       ->checkUserLogin();
    
    }

    public function indexAction($id=null)
    {
         $this->layout="simple";
    }
	
	public function scanAction(){
		$dir = "files";
		
		$response = $this->scan($dir);
		
		header('Content-type: application/json');

		echo json_encode(array(
			"name" => "files",
			"type" => "folder",
			"path" => $dir,
			"items" => $response
		));

		exit;
	}
	
	public function dwnAction(){
		if(!isset($this->get['path'])){
			pre('Invalid Attempted');
		}
		
		$path = COMPONENT_PATH . "/cutefilebrowser/" . $this->get['path'];
		
		if(!file_exists($path)){
			pre('File not found');
		}
		
		App::Utility()->Download($path);
		
		exit;
	}
	
	private function scan($dir){

		$root = COMPONENT_PATH . "/cutefilebrowser/";
        
		$files = array();

		if(file_exists($root.$dir)){
		
			foreach(scandir($root.$dir) as $f) {
			
				if(!$f || $f[0] == '.') {
					continue;
				}

				if(is_dir($root.$dir . '/' . $f)) {

					$files[] = array(
						"name" => $f,
						"type" => "folder",
						"path" => $dir . '/' . $f,
						"items" => $this->scan($dir . '/' . $f) 
					);
				}
				
				else {
					$files[] = array(
						"name" => $f,
						"type" => "file",
						"path" => $dir . '/' . $f,
						"size" => filesize($root . $dir . '/' . $f) // Gets the size of this file
					);
				}
			}
		
		}

		return $files;
	}
}
